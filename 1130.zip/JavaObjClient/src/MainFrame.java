import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BaseMultiResolutionImage;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class MainFrame extends JFrame {
	private static final long serialVersionUID = -8700593713295177769L;
	private JPanel friendsListPanel;
	private JPanel chatsListPanel;
	
	private JPanel contentPane;
	private JPanel friendsPanel;
	private JPanel chatsPanel;
	
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(360, 640);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new BorderLayout(0, 0));
		leftPanel.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
		contentPane.add(leftPanel, BorderLayout.WEST);

		JPanel iconPanel = new JPanel();
		iconPanel.setLayout(new BorderLayout(22, 16));
		leftPanel.add(iconPanel, BorderLayout.NORTH);

		ImageIcon personIcon = new ImageIcon("src/person-fill.png");
		BaseMultiResolutionImage personImage = new BaseMultiResolutionImage(
				personIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH),
				personIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH));

		JLabel friendsButton = new JLabel(new ImageIcon(personImage));
		friendsButton.setVerticalAlignment(SwingConstants.TOP);
		friendsButton.setHorizontalAlignment(SwingConstants.LEADING);
		friendsButton.setBorder(BorderFactory.createEmptyBorder());
		friendsButton.setPreferredSize(new Dimension(24, 20));
		friendsButton.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {
				contentPane.remove(friendsPanel);
				contentPane.remove(chatsPanel);
				contentPane.add(friendsPanel);
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		iconPanel.add(friendsButton, BorderLayout.NORTH);

		ImageIcon chatIcon = new ImageIcon("src/chat-fill.png");
		BaseMultiResolutionImage chatImage = new BaseMultiResolutionImage(
				chatIcon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH),
				chatIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH));

		JLabel chatsButton = new JLabel(new ImageIcon(chatImage));
		chatsButton.setVerticalAlignment(SwingConstants.TOP);
		chatsButton.setHorizontalAlignment(SwingConstants.LEADING);
		chatsButton.setBorder(BorderFactory.createEmptyBorder());
		chatsButton.setPreferredSize(new Dimension(24, 20));
		chatsButton.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {
				contentPane.remove(friendsPanel);
				contentPane.remove(chatsPanel);
				contentPane.add(chatsPanel);
				contentPane.revalidate();
				contentPane.repaint();
			}
		});
		iconPanel.add(chatsButton, BorderLayout.SOUTH);

		// Friends Panel
		friendsPanel = new JPanel();
		friendsPanel.setLayout(new BorderLayout(0, 0));
		contentPane.add(friendsPanel);

		JLabel titleLabel = new JLabel("ģ��");
		titleLabel.setFont(new Font(".AppleSystemUIFont", Font.BOLD, 16));
		titleLabel.setBackground(Color.WHITE);
		titleLabel.setOpaque(true);
		titleLabel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
		friendsPanel.add(titleLabel, BorderLayout.NORTH);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(BorderFactory.createEmptyBorder());
		friendsPanel.add(scrollPane);

		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout(0, 0));
		panel.setBackground(Color.WHITE);
		scrollPane.setViewportView(panel);

		friendsListPanel = new JPanel();
		friendsListPanel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
		friendsListPanel.setLayout(new BoxLayout(friendsListPanel, BoxLayout.PAGE_AXIS));
		friendsListPanel.setBackground(Color.WHITE);
		panel.add(friendsListPanel, BorderLayout.NORTH);

		// Chats Panel
		chatsPanel = new JPanel();
		chatsPanel.setLayout(new BorderLayout(0, 0));
//		contentPane.add(chatsPanel, BorderLayout.CENTER);

		JLabel chatsLabel = new JLabel("ä��");
		chatsLabel.setFont(new Font(".AppleSystemUIFont", Font.BOLD, 16));
		chatsLabel.setBackground(Color.WHITE);
		chatsLabel.setOpaque(true);
		chatsLabel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
		chatsPanel.add(chatsLabel, BorderLayout.NORTH);

		JScrollPane chatsScrollPane = new JScrollPane();
		chatsScrollPane.setBorder(BorderFactory.createEmptyBorder());
		chatsPanel.add(chatsScrollPane);

		JPanel abcd = new JPanel();
		abcd.setLayout(new BorderLayout(0, 0));
		abcd.setBackground(Color.WHITE);
		chatsScrollPane.setViewportView(abcd);

		chatsListPanel = new JPanel();
		chatsListPanel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
		chatsListPanel.setLayout(new BoxLayout(chatsListPanel, BoxLayout.PAGE_AXIS));
		chatsListPanel.setBackground(Color.WHITE);
		abcd.add(chatsListPanel, BorderLayout.NORTH);

		setVisible(true);
	}

	public void addFriend(String name) {
		friendsListPanel.add(new FriendPanel(name));
		friendsListPanel.revalidate();
		friendsListPanel.repaint();
	}

	public void removeFriend(String name) {
		for (Component component : friendsListPanel.getComponents()) {
			FriendPanel friendPanel = (FriendPanel) component;

			if (friendPanel.getName().equals(name)) {
				friendsListPanel.remove(component);
				friendsListPanel.revalidate();
				friendsListPanel.repaint();
				break;
			}
		}
	}
}
